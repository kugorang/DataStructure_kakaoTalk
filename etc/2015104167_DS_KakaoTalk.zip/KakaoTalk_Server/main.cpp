#include "Application.h"

int wmain()
{
	Application app;

	app.Run();

	return 0;
}